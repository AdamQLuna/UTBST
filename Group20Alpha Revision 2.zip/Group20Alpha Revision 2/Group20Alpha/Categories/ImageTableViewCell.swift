//
//  ImageTableViewCell.swift
//  Group20Alpha
//
//  Created by Brandon Head on 3/21/18.
//  Copyright © 2018 Group 20. All rights reserved.
//

import UIKit

class ImageTableViewCell: UITableViewCell {

    @IBOutlet weak var catImage: UIImageView!
    
    @IBOutlet weak var catlabel: UILabel!
    
    var imageName: String = "" {
        
        didSet {
            
            if let catImage = imageView {
                catImage.image = UIImage(named: imageName)
            }
            
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
   // tableView.rowHeight = UITableViewAutomaticDimension
   // tableView.estimatedRowHeight = 60

}
